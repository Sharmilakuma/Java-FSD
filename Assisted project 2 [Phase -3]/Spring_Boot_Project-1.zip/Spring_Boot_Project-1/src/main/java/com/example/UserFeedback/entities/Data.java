package com.example.UserFeedback.entities;

public @interface Data {

}
