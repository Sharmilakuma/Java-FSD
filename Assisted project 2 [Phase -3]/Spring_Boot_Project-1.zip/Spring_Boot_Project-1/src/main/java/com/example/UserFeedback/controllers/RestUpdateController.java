package com.example.UserFeedback.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.UserFeedback.entities.Feedback;
import com.example.UserFeedback.repositories.FeedbackRepository;
import com.example.UserFeedback.services.FeedbackService;

@RestController
public class RestUpdateController {

    @Autowired
    FeedbackService feedbackService;

    @Autowired
    FeedbackRepository feedbackRepository;

    @GetMapping("/update")
    public String updateFeedback(
            @RequestParam("comment") String comment,
            @RequestParam("rating") int rating,
            @RequestParam("name") String name) {

        int nextId = getNextFeedbackId();
        Feedback feedback = new Feedback(nextId, comment, rating, name);
        feedbackRepository.save(feedback);

        return "<html>\n"
                + "<head>\n"
                + " <!-- Your CSS styling here -->\n"
                + "</head>\n"
                + "<body>\n"
                + " <div class=\"center\">\n"
                + " <h1>User Feedback Page</h1>\n"
                + " <h2 class=\"hello-title\">Successfully Added Your Feedback</h2>\n"
                + " <a href=\"/feedback\">Click here to view all feedback</a>\n"
                + " </div>\n"
                + "</body>\n"
                + "</html>";
    }

    private int getNextFeedbackId() {
        int id = 1;
        while (feedbackRepository.existsById(id)) {
            id++;
        }
        return id;
    }
}
