package com.example.UserFeedback.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.UserFeedback.entities.Feedback;
import com.example.UserFeedback.repositories.FeedbackRepository;

@RestController
public class FeedbackController {

    @Autowired
    FeedbackRepository feedbackRepository;

    @GetMapping("/")
    public String showIndexPage(ModelMap model) {
        // ... your HTML code
    }

    @GetMapping("/feedback")
    public String getAllFeedbacks() {
        Iterable<Feedback> allFB = feedbackRepository.findAll();
        StringBuilder tableRows = new StringBuilder();

        for (Feedback feedback : allFB) {
            tableRows.append("<tr>")
                    .append("<td>").append(feedback.getUserName()).append("</td>")
                    .append("<td>").append(feedback.getComments()).append("</td>")
                    .append("<td>").append(feedback.getRating()).append("</td>")
                    .append("</tr>");
        }

        return "<html>\n"
                + "<head>\n"
                + " <!-- Your CSS styling here -->\n"
                + "</head>\n"
                + "<body>\n"
                + " <div class=\"center\">\n"
                + " <h1>Feedback Table</h1>\n"
                + " <table>\n"
                + " <tr>\n"
                + " <th>Name</th>\n"
                + " <th>Comment</th>\n"
                + " <th>Rating</th>\n"
                + " </tr>\n"
                + tableRows.toString() /* Include the table rows with feedback details here */
                + " </table>\n"
                + " </div>\n"
                + "</body>\n"
                + "</html>";
    }
}
