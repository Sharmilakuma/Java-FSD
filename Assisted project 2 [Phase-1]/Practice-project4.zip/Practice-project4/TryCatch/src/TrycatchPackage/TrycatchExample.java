package TrycatchPackage;

public class TrycatchExample {
    public static void main(String[] args) {
        try {
            // Code that may cause an exception
            int result = divideNumbers(10, 0);

            // This line will not be executed if an exception occurs
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Code to handle the exception
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            // Code in the finally block always executes, regardless of whether an exception occurs or not
            System.out.println("Finally block executed");
        }

        // This line will be executed after handling the exception
        System.out.println("Program continues after the exception handling");
    }

    // A method that may throw an ArithmeticException
    private static int divideNumbers(int dividend, int divisor) {
        return dividend / divisor;
    }
}
