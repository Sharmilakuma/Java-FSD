package CURD_Package;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.util.List;

public class FileCURDExample {
    public static void main(String[] args) {
        // Define the file path
        String filePath = "example.txt";

        // Create a file
        createFile(filePath);

        // Read the contents of the file
        readFromFile(filePath);

        // Update the file
        updateFile(filePath, "Updated content");

        // Read the updated contents of the file
        readFromFile(filePath);

        // Delete the file
        deleteFile(filePath);
    }

    private static void createFile(String filePath) {
        try {
            Path path = Paths.get(filePath);
            Files.write(path, "Hello, this is an example file.".getBytes());
            System.out.println("File created successfully.");
        } catch (IOException e) {
            System.err.println("Error creating the file: " + e.getMessage());
        }
    }

    private static void readFromFile(String filePath) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            System.out.println("File content:");
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    private static void updateFile(String filePath, String newContent) {
        try {
            Files.write(Paths.get(filePath), newContent.getBytes());
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }
    }

    private static void deleteFile(String filePath) {
        try {
            Files.delete(Paths.get(filePath));
            System.out.println("File deleted successfully.");
        } catch (IOException e) {
            System.err.println("Error deleting the file: " + e.getMessage());
        }
    }
}




