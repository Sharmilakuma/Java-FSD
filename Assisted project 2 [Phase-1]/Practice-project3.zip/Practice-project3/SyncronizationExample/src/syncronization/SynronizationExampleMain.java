package syncronization;

public class SynronizationExampleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Counter sharedCounter = new Counter();

	        // Creating multiple threads that share the same Counter instance
	        Thread thread1 = new MyThread(sharedCounter);
	        Thread thread2 = new MyThread(sharedCounter);

	        // Start both threads
	        thread1.start();
	        thread2.start();
	    }
	
	}


