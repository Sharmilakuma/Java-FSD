package syncronization;

public class Counter {

	 private int count = 0;

	    // Synchronized method to increment the count
	    public synchronized void increment() {
	        for (int i = 0; i < 5; i++) {
	            count++;
	            System.out.println(Thread.currentThread().getName() + ": Count = " + count);
	            try {
	                Thread.sleep(100); // Simulating some processing time
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }
}