package ClassObjOOP_Package;

public class Inheritance_Test {

	
	    public static void main(String args[])  
	    { 
	    	Inheritance_MountainBike mb = new Inheritance_MountainBike(3, 100, 25); 
	        System.out.println(mb.toString());
	    } 
	}