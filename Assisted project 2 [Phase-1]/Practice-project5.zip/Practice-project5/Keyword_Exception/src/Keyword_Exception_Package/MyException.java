package Keyword_Exception_Package;

class MyException extends Exception 
{ 
    public MyException(String s) 
    { 
        super(s); 
    } 
 

    } 

