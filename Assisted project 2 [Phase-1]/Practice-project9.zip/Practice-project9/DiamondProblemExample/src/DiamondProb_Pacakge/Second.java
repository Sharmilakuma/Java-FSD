package DiamondProb_Pacakge;

public interface Second { 
    default void show() 
    { 
        System.out.println("Default Second"); 
    } 
}  



