package DiamondProb_Pacakge;

public class TestClass implements First, Second {


		    public void show() 
		    {  
		        First.super.show(); 
		        Second.super.show(); 
		    } 
		    public static void main(String args[]) 
		    { 
		        TestClass ob = new TestClass(); 
		        ob.show(); 
		    } 
		}
