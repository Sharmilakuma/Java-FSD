/**
 * 
 */
/**
 * 
 */
module DiamondProblemExample {
}