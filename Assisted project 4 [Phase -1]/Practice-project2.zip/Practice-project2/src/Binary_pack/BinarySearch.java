package Binary_pack;

public class BinarySearch {

    // Function to perform binary search
    public static int binarySearch(int[] arr, int target) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            // Check if the target is present at the middle
            if (arr[mid] == target) {
                return mid;
            }

            // If the target is greater, ignore the left half
            else if (arr[mid] < target) {
                low = mid + 1;
            }

            // If the target is smaller, ignore the right half
            else {
                high = mid - 1;
            }
        }

        return -1; // Return -1 if the target is not found in the array
    }

    public static void main(String[] args) {
        // Example usage
        int[] array = {1, 2, 3, 4, 7, 8, 10, 12, 15};
        int targetElement = 8;

        // Perform binary search
        int result = binarySearch(array, targetElement);

        // Display the result
        if (result != -1) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
