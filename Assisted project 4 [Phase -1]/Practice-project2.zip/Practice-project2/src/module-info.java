/**
 * 
 */
/**
 * 
 */
module BinarySearchAlgorithm {
}