package Expo_pack;

public class ExponentialSearch {

    // Function to perform exponential search
    public static int exponentialSearch(int[] arr, int target) {
        int n = arr.length;
        
        // If the target is the first element
        if (arr[0] == target) {
            return 0;
        }

        // Find the range for binary search by doubling i
        int i = 1;
        while (i < n && arr[i] <= target) {
            i *= 2;
        }

        // Perform binary search in the found range
        return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
    }

    // Function to perform binary search within a specific range
    private static int binarySearch(int[] arr, int target, int low, int high) {
        while (low <= high) {
            int mid = low + (high - low) / 2;

            // Check if the target is present at the middle
            if (arr[mid] == target) {
                return mid;
            }

            // If the target is greater, ignore the left half
            else if (arr[mid] < target) {
                low = mid + 1;
            }

            // If the target is smaller, ignore the right half
            else {
                high = mid - 1;
            }
        }

        return -1; // Return -1 if the target is not found in the array
    }

    public static void main(String[] args) {
        // Example usage
        int[] array = {1, 2, 3, 4, 7, 8, 10, 12, 15};
        int targetElement = 8;

        // Perform exponential search
        int result = exponentialSearch(array, targetElement);

        // Display the result
        if (result != -1) {
            System.out.println("Element found at index: " + result);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
