package MergeSort_pack;

public class MergeSort {

    // Function to perform merge sort
    public static void mergeSort(int[] arr) {
        int n = arr.length;

        // Base case: If the array has one or zero elements, it is already sorted
        if (n <= 1) {
            return;
        }

        // Find the middle of the array
        int mid = n / 2;

        // Create temporary arrays for the left and right halves
        int[] left = new int[mid];
        int[] right = new int[n - mid];

        // Populate the left and right arrays
        System.arraycopy(arr, 0, left, 0, mid);
        System.arraycopy(arr, mid, right, 0, n - mid);

        // Recursively sort the left and right halves
        mergeSort(left);
        mergeSort(right);

        // Merge the sorted halves
        merge(arr, left, right);
    }

    // Function to merge two sorted arrays
    private static void merge(int[] arr, int[] left, int[] right) {
        int nLeft = left.length;
        int nRight = right.length;
        int i = 0, j = 0, k = 0;

        // Compare elements from left and right arrays and merge them into the main array
        while (i < nLeft && j < nRight) {
            if (left[i] <= right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }

        // Copy the remaining elements of left[], if any
        while (i < nLeft) {
            arr[k++] = left[i++];
        }

        // Copy the remaining elements of right[], if any
        while (j < nRight) {
            arr[k++] = right[j++];
        }
    }

    public static void main(String[] args) {
        // Example usage
        int[] array = {38, 27, 43, 3, 9, 82, 10};

        // Perform merge sort
        mergeSort(array);

        // Display the sorted array
        System.out.println("Sorted array:");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
}
