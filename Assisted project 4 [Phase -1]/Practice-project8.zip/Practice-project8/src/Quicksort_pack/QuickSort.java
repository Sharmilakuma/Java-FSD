package Quicksort_pack;

public class QuickSort {

    // Function to perform quick sort
    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            // Find the partition index such that elements smaller than the pivot are on the left,
            // and elements greater than the pivot are on the right
            int partitionIndex = partition(arr, low, high);

            // Recursively sort the elements before and after the partition index
            quickSort(arr, low, partitionIndex - 1);
            quickSort(arr, partitionIndex + 1, high);
        }
    }

    // Function to partition the array and return the partition index
    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high]; // Choose the last element as the pivot
        int i = low - 1;

        // Iterate through the array and rearrange elements such that elements less than the pivot
        // are on the left and elements greater than the pivot are on the right
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;

                // Swap arr[i] and arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // Swap arr[i+1] and arr[high] (put the pivot in its correct position)
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1; // Return the partition index
    }

    public static void main(String[] args) {
        // Example usage
        int[] array = {38, 27, 43, 3, 9, 82, 10};

        // Perform quick sort
        quickSort(array, 0, array.length - 1);

        // Display the sorted array
        System.out.println("Sorted array:");
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
    }
}
